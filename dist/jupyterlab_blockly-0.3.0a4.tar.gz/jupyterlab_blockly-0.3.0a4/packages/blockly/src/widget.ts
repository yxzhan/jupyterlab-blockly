import {
  DocumentRegistry,
  DocumentWidget,
  DocumentModel
} from '@jupyterlab/docregistry';
import { IRenderMimeRegistry } from '@jupyterlab/rendermime';
import { 
  runIcon,
  stopIcon,
  codeIcon,
  refreshIcon,
} from '@jupyterlab/ui-components';

import { SplitPanel } from '@lumino/widgets';
import { Signal } from '@lumino/signaling';

import type Blockly from 'blockly';

import { BlocklyLayout } from './layout';
import { BlocklyManager } from './manager';
import {
  BlocklyButton,
  SelectGenerator,
  SelectToolbox,
  Spacer
} from './toolbar';
import { CodeCell } from '@jupyterlab/cells';

/**
 * DocumentWidget: widget that represents the view or editor for a file type.
 */
export class BlocklyEditor extends DocumentWidget<BlocklyPanel, DocumentModel> {
  constructor(options: BlocklyEditor.IOptions) {
    super(options);

    // Loading the ITranslator
    // const trans = this.translator.load('jupyterlab');

    // Create and add a button to the toolbar to execute
    // the code.
    const runButton = new BlocklyButton({
      label: 'Run Code',
      icon: runIcon,
      className: 'jp-blockly-runButton',
      onClick: () => (this.content.layout as BlocklyLayout).run(),
      tooltip: 'Run Code'
    });
    const stopButton = new BlocklyButton({
      label: 'Stop Code',
      icon: stopIcon,
      onClick: () => {
        const kernel = this.context.sessionContext.session?.kernel;
        if (kernel) {
          return kernel.interrupt();
        }
        return Promise.resolve(void 0);
      },
      tooltip: 'Stop Code'
    });
    const restartButton = new BlocklyButton({
      label: 'Restart the kernel',
      icon: refreshIcon,
      onClick: () => {
        const kernel = this.context.sessionContext.session?.kernel;
        if (kernel) {
          return kernel.restart();
        }
        return Promise.resolve(void 0);
      },
      tooltip: 'Restart the kernel'
    });
    // Hide the source code by default
    options.content.setRelativeSizes([1,0])
    const toggleCodeButton = new BlocklyButton({
      label: 'Show Code',
      icon: codeIcon,
      onClick: () => {
        const isHidden = options.content.relativeSizes()[1] === 0 ? 1 : 0;
        options.content.setRelativeSizes(isHidden ? [0.5, 0.5] : [1, 0])
      },
      tooltip: 'Show or hide source code'
    });
    this.toolbar.addItem('run', runButton);
    this.toolbar.addItem('stop', stopButton);
    this.toolbar.addItem('restart', restartButton);
    this.toolbar.addItem('toggleCode', toggleCodeButton);
    this.toolbar.addItem('spacer', new Spacer());
    this.toolbar.addItem(
      'toolbox',
      new SelectToolbox({
        label: 'Toolbox',
        tooltip: 'Select toolbox',
        manager: options.manager
      })
    );
    this.toolbar.addItem(
      'generator',
      new SelectGenerator({
        label: 'Kernel',
        tooltip: 'Select kernel',
        manager: options.manager
      })
    );
  }

  /**
   * Dispose of the resources held by the widget.
   */
  dispose(): void {
    this.content.dispose();
    super.dispose();
  }
}

export namespace BlocklyEditor {
  export interface IOptions
    extends DocumentWidget.IOptions<BlocklyPanel, DocumentModel> {
    manager: BlocklyManager;
  }
}

/**
 * Widget that contains the main view of the DocumentWidget.
 */
export class BlocklyPanel extends SplitPanel {
  private _context: DocumentRegistry.IContext<DocumentModel>;
  private _rendermime: IRenderMimeRegistry;

  /**
   * Construct a `BlocklyPanel`.
   *
   * @param context - The documents context.
   */
  constructor(
    context: DocumentRegistry.IContext<DocumentModel>,
    manager: BlocklyManager,
    rendermime: IRenderMimeRegistry
  ) {
    super({
      layout: new BlocklyLayout(manager, context.sessionContext, rendermime)
    });
    this.addClass('jp-BlocklyPanel');
    this._context = context;
    this._rendermime = rendermime;

    // Load the content of the file when the context is ready
    this._context.ready.then(() => this._load());
    // Connect to the save signal
    this._context.saveState.connect(this._onSave, this);
  }

  /*
   * The code cell.
   */
  get cell(): CodeCell {
    return (this.layout as BlocklyLayout).cell;
  }

  /*
   * The rendermime instance used in the code cell.
   */
  get rendermime(): IRenderMimeRegistry {
    return this._rendermime;
  }

  /**
   * Dispose of the resources held by the widget.
   */
  dispose(): void {
    if (this.isDisposed) {
      return;
    }
    Signal.clearData(this);
    super.dispose();
  }

  private _load(): void {
    // Loading the content of the document into the workspace
    const content = this._context.model.toJSON() as any as Blockly.Workspace;
    (this.layout as BlocklyLayout).workspace = content;
  }

  private _onSave(
    sender: DocumentRegistry.IContext<DocumentModel>,
    state: DocumentRegistry.SaveState
  ): void {
    if (state === 'started') {
      const workspace = (this.layout as BlocklyLayout).workspace;
      this._context.model.fromJSON(workspace as any);
    }
  }
}
