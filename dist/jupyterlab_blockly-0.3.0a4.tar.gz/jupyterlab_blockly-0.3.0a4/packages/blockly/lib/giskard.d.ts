declare const _default: {
    kind: string;
    colour: string;
    name: string;
    contents: {
        kind: string;
        type: string;
    }[];
};
export default _default;
