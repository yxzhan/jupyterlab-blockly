import { ToolbarButton, ToolbarButtonComponent } from '@jupyterlab/apputils';
import { Widget } from '@lumino/widgets';
export declare class BlocklyButton extends ToolbarButton {
    constructor(props?: ToolbarButtonComponent.IProps);
}
export declare class Spacer extends Widget {
    constructor();
}
